import React from 'react'
import axios from "axios"
import { useEffect,useState } from 'react'
import { Link } from 'react-router-dom'
import App from '../App.css'

const CurrentLaunch = () => {

    const [data,setData] = useState("")


    useEffect(() => {
        axios.get("https://api.spacexdata.com/v4/launches/latest")
            .then(response => {
                console.log(response.data);
                setData(response.data)
            })
            .catch(err => console.log(err))
    }, [])

    return (
        <div style={{width:"400px", margin:"0 auto", opacity:"75%", paddingBottom:"30px",paddingTop:"30px", borderRadius:"75px"}}className="div">
            <h2 style={{color:"white"}}>{data ? data.name : ""}</h2>
            <div style={{color:"white"}}><img src={data ? data.links.patch.small : ""}></img></div>
            <h4 style={{color:"white"}}>{data ? data.date_utc.substring(0,10) : ""}</h4>
        </div>
    )
}

export default CurrentLaunch
