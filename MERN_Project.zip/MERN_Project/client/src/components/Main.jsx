import React from 'react'
import {useState, useEffect} from "react"
import axios from "axios"
import { Link } from 'react-router-dom'
import App from '../App.css'

const Main= () => {

    return (

        <div style={{width:"400px", margin:"0 auto", opacity:"75%", paddingBottom:"30px",paddingTop:"30px", borderRadius:"75px"}} className="div">
            <div style={{marginBottom:"75px", marginTop:"100px"}}>
                <Link to="/info"><button className="glow-on-hover">About</button></Link>
            </div>
            <div style={{marginBottom:"75px"}}>
                <Link to="/launches"><button className="glow-on-hover">All Launches</button></Link>
            </div>
            <div style={{marginBottom:"75px"}}>
                <Link to="/latestLaunch"><button className="glow-on-hover">Latest Launch</button></Link>
            </div>
            <div style={{marginBottom:"75px"}}>
                <Link to="/historicalEvents"><button className="glow-on-hover">Historical Events</button></Link>
            </div>
        </div>
    )
}

export default Main