import React from 'react'
import axios from 'axios'
import { useState } from 'react'

const Launches = () => {

    const [launches, setLaunches] = useState([])
    const [singleLaunch, setSingleLaunch] = useState({})

    const obtainLaunches = () => {
        axios.get("https://api.spacexdata.com/v4/launches")
            .then(response => {
                console.log(response.data);
                setLaunches(response.data)
            })
            .catch(err => console.log(err))
    }
    
    return (
        <div style={{backgroundImage: "url(https://e3.365dm.com/17/12/2048x1152/skynews-spacex-california-pic-danny-sullivan_4190244.jpg)", height:"800px", backgroundSize:"100%", backgroundRepeat:"no-repeat", backgroundAttachment:"fixed"}}>
            {
                launches ?
            <div>
                <button onClick={obtainLaunches}>Obtain Launches</button>
                    <select name="launch" id="launch" onChange={(e) => { setSingleLaunch(e.target.value) }}>
                        {
                            launches.map((launch, idx) => {
                                return (
                                    <option key={idx} value={idx}>{launch.name}</option>
                                )
                            })
                        }
                    </select >
                    <p style={{color:"white"}}>{launches[singleLaunch] ? launches[singleLaunch].name : "Select A Launch"}</p>
                    {/* <img src={launches[singleLaunch].links.patch.small ? launches[singleLaunch].links.patch.small : "Select a Launch"} alt="Patch" /> */}
                    <div>
                        {/* <iframe width="560" height="315" src={launches[singleLaunch].links.webcast} title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe> */}
                        {/* <p style={{color:"white"}}>{launches[singleLaunch] ? launches[singleLaunch].name : "Select A Launch"}</p> */}
                        
                    </div>
                    
            </div> : "Loading"
            }
        </div>
    )
}

export default Launches