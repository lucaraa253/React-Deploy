import React from 'react'
import axios from 'axios'
import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import App from '../App.css'

const Launches = () => {

    const [launches, setLaunches] = useState([])
    const [singleLaunch, setSingleLaunch] = useState({})
    const [count, setCount] = useState(0)



    useEffect(() => {
        axios.get("https://api.spacexdata.com/v4/launches")
            .then(response => {
                console.log(response.data);
                setLaunches(response.data)
            })
            .catch(err => console.log(err))
    }, [])

    const seeDetails = () => {
        setCount(1)
    }

    const hideDetails = () => {
        setCount(0)
    }


    return (
        <div style={{width:"400px", margin:"0 auto", opacity:"75%", paddingBottom:"30px",paddingTop:"30px" , borderRadius:"75px"}}className="div">
            <h3 style={{color:"white", marginBottom:"50px"}}>🚀Choose A Launch🚀</h3>
            <select style={{ marginBottom: "30px" }} name="launch" id="launch" onChange={(e) => { setSingleLaunch(e.target.value) }}>
                {
                    launches.map((launch, idx) => {
                        return (
                            <option key={idx} value={idx}>{launch.name}</option>
                        )
                    })
                }
            </select >
            <div style={{marginBottom:"20px"}}>{launches[singleLaunch] ? <img src={launches[singleLaunch].links.patch.small} alt="" /> : ""}</div>
                {/* <p style={{ color: "white", textDecoration:"underline" }}>Launch Name </p> */}
                
                <p style={{ color: "white", marginBottom:"40px" }}>{launches[singleLaunch] ? launches[singleLaunch].name : ""}</p>
                {/* <p style={{ color: "white", textDecoration:"underline" }}>Details </p> */}
                {
                    launches[singleLaunch] ?
                <p style={{ color: "white", marginBottom:"40px" }}>{count === 0 && launches[singleLaunch].details ? <button onClick={seeDetails}>See Details</button> : ""}{count === 1 ? launches[singleLaunch].details : ""}{!launches[singleLaunch].details ? "🛸🌌Classified Information🌌🛸" : ""}</p>
                : ""
                }
                <p>{count === 1 ? <button onClick={hideDetails}>Close Details</button> : ""}</p>
            </div>
            
    )
}

export default Launches
