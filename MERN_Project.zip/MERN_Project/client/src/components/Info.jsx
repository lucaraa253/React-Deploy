import React from 'react'
import {useState, useEffect} from "react"
import axios from "axios"
import { Link } from 'react-router-dom'
import App from '../App.css'

const Info= () => {

    const [data,setData] = useState("")


    useEffect(() => {
        axios.get("https://api.spacexdata.com/v4/company")
            .then(response => {
                console.log(response.data);
                setData(response.data)
            })
            .catch(err => console.log(err))
    }, [])

    return (

        <div style={{backgroundColor:"black", width:"400px", margin:"0 auto", opacity:"75%", paddingBottom:"30px",paddingTop:"30px", borderRadius:"75px"}} className="div">
            <h3 style={{color:"white", marginBottom:"20px"}}>Location</h3>
            <h5 style={{color:"white", marginBottom:"40px"}}>1 {data ? data.headquarters.address + ", " + data.headquarters.city + ", " + data.headquarters.state : ""}</h5>
            <h3 style={{color:"white", marginBottom:"20px"}}>Official Site</h3>
            <h5 style={{color:"white", marginBottom:"40px"}}>{data ? data.links.website : ""}</h5>
            <h3 style={{color:"white", marginBottom:"20px"}}>Founder</h3>
            <h5 style={{color:"white", marginBottom:"40px"}}>{data ? data.founder : ""}</h5>
        </div>
    )
}

export default Info