import React from 'react'
import axios from 'axios'
import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import App from '../App.css'

const HistoricalEvents = () => {

    const [events, setEvents] = useState([])
    const [option, setOption] = useState({})




    useEffect(() => {
        axios.get("https://api.spacexdata.com/v4/history")
            .then(response => {
                console.log(response.data);
                setEvents(response.data)
            })
            .catch(err => console.log(err))
    }, [])

    return (
        <div style={{width:"400px", margin:"0 auto", opacity:"75%", paddingBottom:"30px",paddingTop:"30px", borderRadius:"75px"}}className="div">
            <div>
            <h3 style={{color:"white", marginBottom:"40px"}}>🚀Choose An Event🚀</h3>
                <select style={{ marginBottom: "30px" }} name="event" id="event" onChange={(e) => { setOption(e.target.value) }}>
                    {
                        events.map((event, idx) => {
                            return (
                                <option key={idx} value={idx}>{event.title}</option>
                            )
                        })
                    }
                </select >
            </div>
            <h3 style={{color:"white", marginBottom:"40px"}}>{events[option] ? events[option].title : ""}</h3>
            <h5 style={{color:"white", marginBottom:"40px"}}>{events[option] ? events[option].details : ""}</h5>

            {/* <h5 style={{color:"white"}}>{events ? events : ""}</h5> */}
            {/* <p style={{color:"white"}}>{JSON.stringify(events)}</p> */}
        </div>
    )
}

export default HistoricalEvents
