import './App.css';
import Launches from './components/Launches';
import Main from './components/Main';
import Info from './components/Info';
import {Redirect,Switch,Route} from "react-router-dom"
import CurrentLaunch from './components/CurrentLaunch';
import HistoricalEvents from './components/HistoricalEvents';
import {useState} from "react"
import { Link } from 'react-router-dom'

function App() {


  const [img, setImg] = useState("url(https://50skyshades.com/images/o/spacex-falcon-9-booster-achieves-epic-vertical-landing-5637-NrBB21ItGax91pyzo8AzuDQ2Y.jpg)");
  const [count, setCount] = useState(0)


  const nightMode = () => {
    setCount(1)
    setImg("url(https://www.universetoday.com/wp-content/uploads/2009/01/falcon9_vertical002.jpg)")
  }

  const dayMode = () => {
    setCount(0);
    setImg("url(https://50skyshades.com/images/o/spacex-falcon-9-booster-achieves-epic-vertical-landing-5637-NrBB21ItGax91pyzo8AzuDQ2Y.jpg)")
  }

  return (
    <div className="App" style={{backgroundImage: img, height:"1600px", backgroundSize:"100%", backgroundRepeat:"no-repeat", backgroundAttachment:"fixed", width:"100%"}}>
      <h1 style={{color:"white", paddingTop:"20px", paddingBottom:"30px"}}>SpaceX</h1>
      <div>
        <Link to="/main"><button className="glow-on-hover" style={{marginBottom:"30px"}}>🚀 Main Page 🚀</button></Link>
      </div>
      {
        count === 0 ?
        <button onClick={nightMode} className="glow-on-hover" style={{marginBottom:"30px", width:"120px"}}>🌞Day Mode🌞</button>
        :
        <button onClick={dayMode} className="glow-on-hover" style={{marginBottom:"30px", width:"120px"}}>🌑Night Mode🌑</button>
      }
      <hr/>
      <div style={{marginBottom:"30px"}}></div>
      <Switch>
        <Route path="/launches">
          <Launches/>
        </Route>
        <Route path="/historicalEvents">
          <HistoricalEvents/>
        </Route>
        <Route path="/info">
          <Info/>
        </Route>
        <Route path="/latestLaunch">
          <CurrentLaunch/>
        </Route>
        <Route path="/main">
          <Main/>
        </Route>
        <Route to="/">
          <Redirect to="/Main"/>
        </Route>
      </Switch>
    </div>
  );
}

export default App;
